function int sumaSuma(int x, int y){return 0;} 
sumaSuma(1);